package com.restapi.BundlesProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BundlesProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
